#!/bin/bash

wget --progress=dot:mega --random-wait https://github.com/SCPF-Archive/repo.1/releases/download/com.myprog.hexedit.apk/com.myprog.hexedit.apk -O com.myprog.hexedit.apk
