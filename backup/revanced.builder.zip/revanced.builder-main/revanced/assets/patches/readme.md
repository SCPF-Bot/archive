#### In here you can edit the patches to update or change the applied patches.

- Check the available patches of ReVanced applications [here](https://github.com/revanced/revanced-patches).
